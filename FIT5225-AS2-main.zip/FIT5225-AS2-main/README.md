# FIT5225-AS2

s3_image_upload_db contains 3.2 where the lambda function is triggered on uploading image to s3
image-upload.py contains the 3.3 2nd query (POST method)where when uploaded an image we will get the images which have same tags
query-tag-imagelist-1.js contains the remaining 3.3 query 
     GET Method - Get image links based on the tags provided
     POST Method - To add tags to a given image
     DELETE Method - To delete from the database and s3
